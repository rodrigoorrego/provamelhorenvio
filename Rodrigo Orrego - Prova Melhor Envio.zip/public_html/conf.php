<?php

$servidorconf = "mysql.hostinger.com.br"; 
$usuarioconf = "u413156359_envio"; 
$senhaconf = "envio123"; 
$bdconf = "u413156359_envio"; 

?>